/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef MKSUNXI_PRIVATE_H
#define MKSUNXI_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.0.0.0"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	0
#define VER_BUILD	0
#define COMPANY_NAME	"QQ26750452"
#define FILE_VERSION	"1.0.0.0"
#define FILE_DESCRIPTION	"�ӹ�F1C100s����Ĺ���"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"mksunxi-win32"
#define PRODUCT_VERSION	"1.0.0.0"

#endif /*MKSUNXI_PRIVATE_H*/
